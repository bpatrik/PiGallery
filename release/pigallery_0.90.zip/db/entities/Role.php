<?php

namespace piGallery\db\entities;


class Role {

    const User = 0;
    const Admin = 1;
}