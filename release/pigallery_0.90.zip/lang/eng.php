<?php
/*English language file*/
$LANG = array();
$LANG['html_language_code'] = "en";
$LANG['site_name'] = "PiGallery";
$LANG['PleaseSignIn'] = "Please sign in";
$LANG['username'] = "User name";
$LANG['password'] = "Password";
$LANG['rememberme'] = "Remember me";
$LANG['signin'] = "Sign in";
$LANG['signinInProgress'] = "Signing in...";
$LANG['gallery'] = "Gallery";
$LANG['images'] = "Images";
$LANG['logout'] = "Log out";
$LANG['search'] = "Search";
$LANG['share'] = "Share";
$LANG['searchingfor'] = "Searching for:";

$LANG['admin_users'] = "Users";
$LANG['admin_userName'] = "Username";
$LANG['admin_role'] = "Role";
$LANG['admin_addNewUser'] = "Add new user";
$LANG['admin_password'] = "Password";
$LANG['admin_role_user'] = "Users";
$LANG['admin_role_admin'] = "Admin";
$LANG['admin_add'] = "Add";
$LANG['admin_photos'] = "Photos";
$LANG['admin_clearIndex'] = "Clear Index";
$LANG['admin_indexPhotos'] = "Index Photos";
$LANG['admin_database'] = "Database";
$LANG['admin_resetDatabase'] = "Reset Database";