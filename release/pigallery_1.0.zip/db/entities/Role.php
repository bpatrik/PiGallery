<?php

namespace piGallery\db\entities;


class Role {

    const RemoteGuest = 10;
    const LocalGuest = 11;
    const User = 20;
    const Admin = 30;
}